<?php
/**
 * Plugin Name: TechVision Custom Post Types
 * Plugin URI:  https://github.com/jurogrammer/portfolio-demos
 * Description: Registers Portfolio and Career custom post types with taxonomies for TechVision Solutions.
 * Version:     1.0.0
 * Author:      TechVision Solutions
 * Text Domain: techvision-cpt
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ─────────────────────────────────────────────
// 1. Custom Post Types
// ─────────────────────────────────────────────

function techvision_register_post_types() {

    // ── Portfolio ──────────────────────────────
    register_post_type( 'tv_portfolio', [
        'labels' => [
            'name'               => __( '포트폴리오', 'techvision-cpt' ),
            'singular_name'      => __( '포트폴리오', 'techvision-cpt' ),
            'add_new'            => __( '새 항목 추가', 'techvision-cpt' ),
            'add_new_item'       => __( '포트폴리오 추가', 'techvision-cpt' ),
            'edit_item'          => __( '포트폴리오 편집', 'techvision-cpt' ),
            'new_item'           => __( '새 포트폴리오', 'techvision-cpt' ),
            'view_item'          => __( '포트폴리오 보기', 'techvision-cpt' ),
            'search_items'       => __( '포트폴리오 검색', 'techvision-cpt' ),
            'not_found'          => __( '포트폴리오를 찾을 수 없습니다', 'techvision-cpt' ),
            'not_found_in_trash' => __( '휴지통에 포트폴리오가 없습니다', 'techvision-cpt' ),
            'menu_name'          => __( '포트폴리오', 'techvision-cpt' ),
        ],
        'public'             => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'show_in_rest'       => true,   // Gutenberg + REST API support
        'menu_position'      => 5,
        'menu_icon'          => 'dashicons-portfolio',
        'supports'           => [ 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ],
        'has_archive'        => true,
        'rewrite'            => [ 'slug' => 'portfolio', 'with_front' => false ],
        'capability_type'    => 'post',
        'taxonomies'         => [ 'tv_portfolio_category' ],
    ] );

    // ── Career ─────────────────────────────────
    register_post_type( 'tv_career', [
        'labels' => [
            'name'               => __( '채용공고', 'techvision-cpt' ),
            'singular_name'      => __( '채용공고', 'techvision-cpt' ),
            'add_new'            => __( '새 공고 추가', 'techvision-cpt' ),
            'add_new_item'       => __( '채용공고 추가', 'techvision-cpt' ),
            'edit_item'          => __( '채용공고 편집', 'techvision-cpt' ),
            'new_item'           => __( '새 채용공고', 'techvision-cpt' ),
            'view_item'          => __( '채용공고 보기', 'techvision-cpt' ),
            'search_items'       => __( '채용공고 검색', 'techvision-cpt' ),
            'not_found'          => __( '채용공고를 찾을 수 없습니다', 'techvision-cpt' ),
            'not_found_in_trash' => __( '휴지통에 채용공고가 없습니다', 'techvision-cpt' ),
            'menu_name'          => __( '채용', 'techvision-cpt' ),
        ],
        'public'             => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'show_in_rest'       => true,
        'menu_position'      => 6,
        'menu_icon'          => 'dashicons-businessperson',
        'supports'           => [ 'title', 'editor', 'custom-fields' ],
        'has_archive'        => true,
        'rewrite'            => [ 'slug' => 'careers', 'with_front' => false ],
        'capability_type'    => 'post',
        'taxonomies'         => [ 'tv_career_type' ],
    ] );
}
add_action( 'init', 'techvision_register_post_types' );


// ─────────────────────────────────────────────
// 2. Taxonomies
// ─────────────────────────────────────────────

function techvision_register_taxonomies() {

    // ── Portfolio Category ─────────────────────
    register_taxonomy( 'tv_portfolio_category', 'tv_portfolio', [
        'labels' => [
            'name'              => __( '포트폴리오 카테고리', 'techvision-cpt' ),
            'singular_name'     => __( '카테고리', 'techvision-cpt' ),
            'search_items'      => __( '카테고리 검색', 'techvision-cpt' ),
            'all_items'         => __( '모든 카테고리', 'techvision-cpt' ),
            'parent_item'       => __( '상위 카테고리', 'techvision-cpt' ),
            'parent_item_colon' => __( '상위 카테고리:', 'techvision-cpt' ),
            'edit_item'         => __( '카테고리 편집', 'techvision-cpt' ),
            'update_item'       => __( '카테고리 업데이트', 'techvision-cpt' ),
            'add_new_item'      => __( '새 카테고리 추가', 'techvision-cpt' ),
            'new_item_name'     => __( '새 카테고리 이름', 'techvision-cpt' ),
            'menu_name'         => __( '카테고리', 'techvision-cpt' ),
        ],
        'hierarchical'      => true,
        'show_ui'           => true,
        'show_in_rest'      => true,
        'show_admin_column' => true,
        'rewrite'           => [ 'slug' => 'portfolio-category' ],
    ] );

    // ── Career Type ────────────────────────────
    register_taxonomy( 'tv_career_type', 'tv_career', [
        'labels' => [
            'name'          => __( '고용 형태', 'techvision-cpt' ),
            'singular_name' => __( '고용 형태', 'techvision-cpt' ),
            'menu_name'     => __( '고용 형태', 'techvision-cpt' ),
            'all_items'     => __( '모든 고용 형태', 'techvision-cpt' ),
            'edit_item'     => __( '고용 형태 편집', 'techvision-cpt' ),
            'add_new_item'  => __( '새 고용 형태 추가', 'techvision-cpt' ),
            'new_item_name' => __( '새 고용 형태 이름', 'techvision-cpt' ),
        ],
        'hierarchical'      => false,
        'show_ui'           => true,
        'show_in_rest'      => true,
        'show_admin_column' => true,
        'rewrite'           => [ 'slug' => 'career-type' ],
    ] );
}
add_action( 'init', 'techvision_register_taxonomies' );


// ─────────────────────────────────────────────
// 3. Flush rewrite rules on activation/deactivation
// ─────────────────────────────────────────────

function techvision_activate() {
    techvision_register_post_types();
    techvision_register_taxonomies();
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'techvision_activate' );

function techvision_deactivate() {
    flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'techvision_deactivate' );


// ─────────────────────────────────────────────
// 4. Load ACF field groups
// ─────────────────────────────────────────────

if ( function_exists( 'acf_add_local_field_group' ) ) {
    require_once plugin_dir_path( __FILE__ ) . 'acf-fields.php';
}
