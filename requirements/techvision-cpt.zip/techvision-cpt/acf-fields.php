<?php
/**
 * ACF Local Field Groups for TechVision CPTs
 *
 * Defines field groups programmatically so they are version-controlled
 * and do not require database import.
 *
 * Requires: Advanced Custom Fields (ACF) plugin >= 5.x
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ─────────────────────────────────────────────
// 1. Portfolio Fields
// ─────────────────────────────────────────────

acf_add_local_field_group( [
    'key'    => 'group_tv_portfolio',
    'title'  => '포트폴리오 상세 정보',
    'fields' => [

        // Client / 클라이언트
        [
            'key'           => 'field_tv_portfolio_client',
            'label'         => '클라이언트',
            'name'          => 'tv_client',
            'type'          => 'text',
            'instructions'  => '고객사 이름을 입력하세요.',
            'required'      => 0,
            'placeholder'   => '예: 삼성전자',
        ],

        // Project URL / 프로젝트 URL
        [
            'key'           => 'field_tv_portfolio_url',
            'label'         => '프로젝트 URL',
            'name'          => 'tv_project_url',
            'type'          => 'url',
            'instructions'  => '라이브 프로젝트 링크 (선택)',
            'required'      => 0,
            'placeholder'   => 'https://',
        ],

        // Technologies / 사용 기술
        [
            'key'           => 'field_tv_portfolio_tech',
            'label'         => '사용 기술',
            'name'          => 'tv_technologies',
            'type'          => 'text',
            'instructions'  => '쉼표로 구분된 기술 스택 (예: React, Next.js, TypeScript)',
            'required'      => 0,
            'placeholder'   => 'React, Next.js, TypeScript',
        ],

        // Duration / 프로젝트 기간
        [
            'key'           => 'field_tv_portfolio_duration',
            'label'         => '프로젝트 기간',
            'name'          => 'tv_duration',
            'type'          => 'text',
            'instructions'  => '예: 2024.01 – 2024.06',
            'required'      => 0,
            'placeholder'   => '2024.01 – 2024.06',
        ],

        // Completion Year / 완료 연도
        [
            'key'           => 'field_tv_portfolio_year',
            'label'         => '완료 연도',
            'name'          => 'tv_year',
            'type'          => 'number',
            'instructions'  => '프로젝트 완료 연도',
            'required'      => 0,
            'min'           => 2000,
            'max'           => 2099,
            'step'          => 1,
            'placeholder'   => '2024',
        ],

        // Featured / 대표 프로젝트 여부
        [
            'key'           => 'field_tv_portfolio_featured',
            'label'         => '대표 프로젝트',
            'name'          => 'tv_featured',
            'type'          => 'true_false',
            'instructions'  => '홈 화면에 표시할 대표 프로젝트인 경우 체크하세요.',
            'required'      => 0,
            'default_value' => 0,
            'ui'            => 1,
            'ui_on_text'    => '예',
            'ui_off_text'   => '아니오',
        ],

        // Gallery / 갤러리 이미지
        [
            'key'           => 'field_tv_portfolio_gallery',
            'label'         => '갤러리 이미지',
            'name'          => 'tv_gallery',
            'type'          => 'gallery',
            'instructions'  => '프로젝트 스크린샷 또는 이미지를 업로드하세요.',
            'required'      => 0,
            'return_format' => 'array',
            'preview_size'  => 'medium',
            'insert'        => 'append',
            'library'       => 'all',
            'min'           => 0,
            'max'           => 20,
            'min_width'     => '',
            'min_height'    => '',
            'min_size'      => '',
            'max_width'     => '',
            'max_height'    => '',
            'max_size'      => '',
            'mime_types'    => 'jpg, jpeg, png, webp',
        ],

        // Results / 성과 및 결과
        [
            'key'           => 'field_tv_portfolio_results',
            'label'         => '성과 및 결과',
            'name'          => 'tv_results',
            'type'          => 'textarea',
            'instructions'  => '프로젝트 성과를 간략히 설명하세요 (예: 전환율 30% 향상).',
            'required'      => 0,
            'rows'          => 3,
            'new_lines'     => 'br',
        ],
    ],
    'location' => [
        [
            [
                'param'    => 'post_type',
                'operator' => '==',
                'value'    => 'tv_portfolio',
            ],
        ],
    ],
    'menu_order'            => 0,
    'position'              => 'normal',
    'style'                 => 'default',
    'label_placement'       => 'top',
    'instruction_placement' => 'label',
    'active'                => true,
] );


// ─────────────────────────────────────────────
// 2. Career Fields
// ─────────────────────────────────────────────

acf_add_local_field_group( [
    'key'    => 'group_tv_career',
    'title'  => '채용공고 상세 정보',
    'fields' => [

        // Department / 부서
        [
            'key'           => 'field_tv_career_department',
            'label'         => '부서',
            'name'          => 'tv_department',
            'type'          => 'text',
            'instructions'  => '담당 부서를 입력하세요.',
            'required'      => 1,
            'placeholder'   => '예: 개발팀',
        ],

        // Location / 근무지
        [
            'key'           => 'field_tv_career_location',
            'label'         => '근무지',
            'name'          => 'tv_location',
            'type'          => 'text',
            'instructions'  => '근무 위치를 입력하세요.',
            'required'      => 1,
            'placeholder'   => '서울특별시 강남구',
        ],

        // Employment Type / 고용 형태 (select)
        [
            'key'           => 'field_tv_career_employment_type',
            'label'         => '고용 형태',
            'name'          => 'tv_employment_type',
            'type'          => 'select',
            'instructions'  => '고용 형태를 선택하세요.',
            'required'      => 1,
            'choices'       => [
                'fulltime'   => '정규직',
                'parttime'   => '파트타임',
                'contract'   => '계약직',
                'internship' => '인턴십',
                'freelance'  => '프리랜서',
            ],
            'default_value' => 'fulltime',
            'allow_null'    => 0,
            'multiple'      => 0,
            'ui'            => 1,
            'return_format' => 'value',
        ],

        // Experience Level / 경력 수준
        [
            'key'           => 'field_tv_career_experience',
            'label'         => '경력 수준',
            'name'          => 'tv_experience_level',
            'type'          => 'select',
            'instructions'  => '요구 경력 수준을 선택하세요.',
            'required'      => 1,
            'choices'       => [
                'entry'    => '신입',
                'junior'   => '주니어 (1–3년)',
                'mid'      => '미드 레벨 (3–5년)',
                'senior'   => '시니어 (5년+)',
                'lead'     => '리드 / 매니저',
            ],
            'default_value' => 'entry',
            'allow_null'    => 0,
            'multiple'      => 0,
            'ui'            => 1,
            'return_format' => 'value',
        ],

        // Salary Range / 급여 범위
        [
            'key'           => 'field_tv_career_salary',
            'label'         => '급여 범위',
            'name'          => 'tv_salary_range',
            'type'          => 'text',
            'instructions'  => '급여 범위를 입력하세요 (선택). 예: 4,000만원 – 6,000만원',
            'required'      => 0,
            'placeholder'   => '4,000만원 – 6,000만원',
        ],

        // Application Deadline / 지원 마감일
        [
            'key'              => 'field_tv_career_deadline',
            'label'            => '지원 마감일',
            'name'             => 'tv_deadline',
            'type'             => 'date_picker',
            'instructions'     => '채용 마감일을 선택하세요. 비워두면 상시 채용으로 표시됩니다.',
            'required'         => 0,
            'display_format'   => 'Y년 m월 d일',
            'return_format'    => 'Y-m-d',
            'first_day'        => 0,
        ],

        // Requirements / 자격 요건
        [
            'key'           => 'field_tv_career_requirements',
            'label'         => '자격 요건',
            'name'          => 'tv_requirements',
            'type'          => 'wysiwyg',
            'instructions'  => '지원 자격 요건을 입력하세요.',
            'required'      => 0,
            'tabs'          => 'all',
            'toolbar'       => 'basic',
            'media_upload'  => 0,
        ],

        // Preferred Qualifications / 우대 사항
        [
            'key'           => 'field_tv_career_preferred',
            'label'         => '우대 사항',
            'name'          => 'tv_preferred_qualifications',
            'type'          => 'wysiwyg',
            'instructions'  => '우대하는 자격 요건을 입력하세요.',
            'required'      => 0,
            'tabs'          => 'all',
            'toolbar'       => 'basic',
            'media_upload'  => 0,
        ],

        // Benefits / 복리후생
        [
            'key'           => 'field_tv_career_benefits',
            'label'         => '복리후생',
            'name'          => 'tv_benefits',
            'type'          => 'wysiwyg',
            'instructions'  => '복리후생 및 근무 환경을 입력하세요.',
            'required'      => 0,
            'tabs'          => 'all',
            'toolbar'       => 'basic',
            'media_upload'  => 0,
        ],

        // Is Active / 채용 활성 여부
        [
            'key'           => 'field_tv_career_active',
            'label'         => '채용 진행 중',
            'name'          => 'tv_is_active',
            'type'          => 'true_false',
            'instructions'  => '현재 채용이 진행 중인 경우 활성화하세요.',
            'required'      => 0,
            'default_value' => 1,
            'ui'            => 1,
            'ui_on_text'    => '진행 중',
            'ui_off_text'   => '마감',
        ],
    ],
    'location' => [
        [
            [
                'param'    => 'post_type',
                'operator' => '==',
                'value'    => 'tv_career',
            ],
        ],
    ],
    'menu_order'            => 0,
    'position'              => 'normal',
    'style'                 => 'default',
    'label_placement'       => 'top',
    'instruction_placement' => 'label',
    'active'                => true,
] );
