<?php
/**
 * Kadence Child Theme — Functions
 *
 * Enqueues Google Fonts (Noto Serif KR, Noto Sans KR), parent theme styles,
 * and TechVision custom CSS.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ─────────────────────────────────────────────
// 1. Enqueue styles
// ─────────────────────────────────────────────

function techvision_child_enqueue_styles() {

    // Parent Kadence theme stylesheet
    wp_enqueue_style(
        'kadence-parent-style',
        get_template_directory_uri() . '/style.css',
        [],
        wp_get_theme( 'kadence' )->get( 'Version' )
    );

    // Google Fonts — Noto Serif KR (heading) + Noto Sans KR (body)
    wp_enqueue_style(
        'techvision-google-fonts',
        'https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@300;400;500;600;700&family=Noto+Serif+KR:wght@400;500;600;700&display=swap',
        [],
        null
    );

    // Child theme stylesheet (cascades over parent)
    wp_enqueue_style(
        'techvision-child-style',
        get_stylesheet_directory_uri() . '/style.css',
        [ 'kadence-parent-style', 'techvision-google-fonts' ],
        wp_get_theme()->get( 'Version' )
    );
}
add_action( 'wp_enqueue_scripts', 'techvision_child_enqueue_styles' );


// ─────────────────────────────────────────────
// 2. Theme setup
// ─────────────────────────────────────────────

function techvision_child_setup() {
    // Inherit parent translations
    load_child_theme_textdomain( 'techvision-child', get_stylesheet_directory() . '/languages' );

    // Thumbnail support (already in Kadence, but explicit for safety)
    add_theme_support( 'post-thumbnails' );

    // Custom image sizes used in portfolio grid
    add_image_size( 'tv-portfolio-card', 800, 560, true );
    add_image_size( 'tv-portfolio-hero', 1920, 800, true );
}
add_action( 'after_setup_theme', 'techvision_child_setup' );


// ─────────────────────────────────────────────
// 3. Kadence Global Color Palette — TechVision brand
// ─────────────────────────────────────────────

function techvision_kadence_color_palette( $palette ) {
    return [
        [ 'color' => '#00194a', 'name' => 'Navy (Primary)',  'slug' => 'tv-navy'        ],
        [ 'color' => '#00205c', 'name' => 'Navy Dark',       'slug' => 'tv-navy-dark'   ],
        [ 'color' => '#0080fb', 'name' => 'Accent Blue',     'slug' => 'tv-accent'      ],
        [ 'color' => '#f5f6fb', 'name' => 'Background Light','slug' => 'tv-bg-light'    ],
        [ 'color' => '#111111', 'name' => 'Text Dark',       'slug' => 'tv-text-dark'   ],
        [ 'color' => '#666666', 'name' => 'Text Muted',      'slug' => 'tv-text-muted'  ],
        [ 'color' => '#d4d4d4', 'name' => 'Border',          'slug' => 'tv-border'      ],
        [ 'color' => '#ffffff', 'name' => 'White',           'slug' => 'tv-white'       ],
    ];
}
add_filter( 'kadence_color_palette', 'techvision_kadence_color_palette' );


// ─────────────────────────────────────────────
// 4. Add preconnect for Google Fonts
// ─────────────────────────────────────────────

function techvision_preconnect_fonts() {
    echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
}
add_action( 'wp_head', 'techvision_preconnect_fonts', 1 );


// ─────────────────────────────────────────────
// 5. Disable Kadence's default Google Fonts loading
//    (we load our own subset above)
// ─────────────────────────────────────────────

add_filter( 'kadence_display_google_fonts', '__return_false' );


// ─────────────────────────────────────────────
// 6. Register navigation menus
// ─────────────────────────────────────────────

function techvision_register_menus() {
    register_nav_menus( [
        'primary'    => __( '기본 메뉴', 'techvision-child' ),
        'footer-nav' => __( '푸터 메뉴', 'techvision-child' ),
    ] );
}
add_action( 'init', 'techvision_register_menus' );


// ─────────────────────────────────────────────
// 7. Portfolio archive — posts per page
// ─────────────────────────────────────────────

function techvision_portfolio_archive_query( $query ) {
    if ( ! is_admin() && $query->is_main_query() && $query->is_post_type_archive( 'tv_portfolio' ) ) {
        $query->set( 'posts_per_page', 12 );
        $query->set( 'orderby', 'date' );
        $query->set( 'order', 'DESC' );
    }
}
add_action( 'pre_get_posts', 'techvision_portfolio_archive_query' );


// ─────────────────────────────────────────────
// 8. Career archive — only active positions
// ─────────────────────────────────────────────

function techvision_career_archive_query( $query ) {
    if ( ! is_admin() && $query->is_main_query() && $query->is_post_type_archive( 'tv_career' ) ) {
        $query->set( 'posts_per_page', 20 );
        $query->set( 'meta_query', [
            'relation' => 'OR',
            [
                'key'     => 'tv_is_active',
                'value'   => '1',
                'compare' => '=',
            ],
            [
                'key'     => 'tv_is_active',
                'compare' => 'NOT EXISTS',
            ],
        ] );
    }
}
add_action( 'pre_get_posts', 'techvision_career_archive_query' );
